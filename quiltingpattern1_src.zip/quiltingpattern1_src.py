#-------------------------------------------------------------------------------
# Name:        Quilting Pattern
# Purpose:
#
# Author:      David Muller
#
# Created:     06/08/2014
# Copyright:   (c) David Muller 2014
# Licence:     <your license>
#-------------------------------------------------------------------------------
from tkinter import *
from tkinter import colorchooser
from tkinter import filedialog

class QuiltPattern(object):
    """
    An object of this class represents a half-square triangle quilting pattern.
    Attributes:
        all_pieces (dictionary): a tuple:int dictionary, with each tuple being
            a (column, row, quadrant) representation of a triangle on the quilt
            and each int being used to refer to triangles drawn by tkinter with
            create_polygon().
        colorlist (list): a list of each triangle's color.
        color_entry (Entry): a text box for entering the color of a triangle.
        frame (Frame): a tkinter Frame that holds the visible quilt.
        instructions (Label): a Label with instructions.
        parent (Tk): a reference to the root Tk object.
        pattern (Canvas): the visible quilt, containing drawn triangles.
    """
    def __init__(self, parent):
        parent.title("Quilting Patterns") # title for the window
        self.parent = parent

        # Here's the frame:
        self.frame = Frame(parent)
        self.frame.pack()

        # Label for text box
        self.instructions = Label(self.frame, \
        text="Ctrl+S to save, Ctrl+L to load, Ctrl+D to clear. " + \
        "Left-click for paint bucket, right-click for eyedropper. " + \
        "Enter color: ")
        self.instructions.grid(row=1, column=0, sticky='E')

        # Text box for entering a color name
        self.color_entry = Entry(self.frame, width=32)
        self.color_entry.grid(row=1, column=1, sticky='W')
        self.draw_pattern()

        # These are the controls
        self.parent.bind("<Control-s>", self.save)
        self.parent.bind("<Control-l>", self.load)
        self.parent.bind("<Control-d>", self.clear)
        self.parent.bind("<Control-S>", self.save)
        self.parent.bind("<Control-L>", self.load)
        self.parent.bind("<Control-D>", self.clear)

    def draw_pattern(self):
        """
        Draws the quilting pattern.
        """
        self.pattern = Canvas(self.frame, width=805, height = 805)
        # put the Canvas into the Frame
        self.pattern.grid(row=0, column=0, columnspan=2)
        self.all_pieces = {}

        # options for the triangles we're creating - easily-mutable if necessary
        linewidth = 1
        fillcolor = 'white'
        outlinecolor = 'black'
        activefillcolor = 'black'

        for row in range(4): # for each row
            for column in range(4): # and each column
                # create a dictionary entry mapping this (column, row, quadrant)
                # to a created polygon - top quadrant first
                self.all_pieces[(column, row, 0)] = \
                self.pattern.create_polygon( \
                [column*200+5,row*200+5, \
                column*200+205,row*200+5, \
                column*200+105,row*200+105], \
                fill=fillcolor, outline=outlinecolor, width=linewidth, \
                activefill=activefillcolor)

                # now the left quadrant
                self.all_pieces[(column, row, 1)] = \
                self.pattern.create_polygon( \
                [column*200+5,row*200+5, \
                column*200+5,row*200+205, \
                column*200+105,row*200+105], \
                fill=fillcolor, outline=outlinecolor, width=linewidth, \
                activefill=activefillcolor)

                # now the right quadrant
                self.all_pieces[(column, row, 2)] = \
                self.pattern.create_polygon( \
                [column*200+205,row*200+205, \
                column*200+205,row*200+5, \
                column*200+105,row*200+105], \
                fill=fillcolor, outline=outlinecolor, width=linewidth, \
                activefill=activefillcolor)

                # now the bottom quadrant
                self.all_pieces[(column, row, 3)] = \
                self.pattern.create_polygon( \
                [column*200+5,row*200+205, \
                column*200+205,row*200+205, \
                column*200+105,row*200+105], \
                fill=fillcolor, outline=outlinecolor, width=linewidth, \
                activefill=activefillcolor)

        self.pattern.bind("<Button-1>", self.paint_bucket) # bind left mouse button
        self.pattern.bind("<Button-3>", self.eyedropper) # right mouse button

        # create a list that saves each triangle's color
        self.colorlist = ['white' for num in range(64)]

    def save(self, event):
        """
        Saves the current color arrangement to a file.
        Parameter:
            event (sequence): data describing the input. In this case, it's
            just the keyboard input used to access this method.
        """
        filename = filedialog.asksaveasfilename() # dialog box!
        if filename != None and filename[-4:] != ".txt":
            filename += ".txt" # make sure it ends with '.txt'

        try: # write the color list to a file with the specified name
            with open(filename, 'w', encoding = 'utf-8-sig') as output:
                for item in self.colorlist:
                    output.write(item + "\n")
        except: # if that doesn't work for some reason
            self.color_entry.delete(0, END) # wipe the entry field
            self.color_entry.insert(0, "File couldn't be saved!\t") # say so

    def load(self, event):
        """
        Loads the current color arrangement from a file.
        Parameter:
            event (sequence): data describing the input. In this case, it's
            just the keyboard input used to access this method.
        """
        filename = filedialog.askopenfilename() # dialog box!

        counter = 0 # we'll start with a counter of 0
        try: # open the specified file and write the contents to the list
            with open(filename, 'r', encoding = 'utf-8-sig') as file:
                for line in file:
                    # counter is used to access the colorlist
                    self.colorlist[counter] = line[:-1]
                    counter += 1 # remember to increment it
        except: # if that doesn't work for some reason
            self.color_entry.delete(0, END) # wipe the entry field
            self.color_entry.insert(0, "No file selected.\t") # say so
            return # end this method early

        # now we actually color each triangle according to the list
        try:
            for num in range(64):
                self.pattern.itemconfig(num+1, fill=self.colorlist[num])
        except: # if something is wrong with the file
            self.color_entry.delete(0, END) # wipe the entry field
            self.color_entry.insert(0, "File invalid or corrupt.\t") # say so

    def clear(self, event):
        """
        Clears the quilt, making each triangle white.
        Parameter:
            event (sequence): data describing the input. In this case, it's
            just the keyboard input used to access this method.
        """
        # just make everything white
        self.colorlist = ['white' for num in range(64)]
        for num in range(64):
            self.pattern.itemconfig(num+1, fill=self.colorlist[num])

    def click_process(self, event):
        """
        Processes a mouse click sequence for other functions to determine
        which triangle was selected.
        Parameter:
            event (sequence): data describing the input. In this case, it's
            just the mouse cursor coordinates when the mouse was left-clicked.
        """
        # first we'll get the column and the box-specific x-coordinate
        column, x = divmod(event.x-5, 200)
        # then the row and the box-specific y-coordinate
        row, y = divmod(event.y-5, 200)

        # now to determine which triangle was clicked on.
        if x<100 and y<100: # if it's in the upper-left
            if x>y: # and above the line
                quadrant=0 # it's quadrant 0, the top quadrant
            else: # otherwise
                quadrant=1 # it's quadrant 1, the left quadrant
        if x>=100 and y<100: # if it's in the upper-right
            if x-100<100-y: # and above the line
                quadrant=0 # it's quadrant 0, the top quadrant
            else: # otherwise
                quadrant=2 # it's quadrant 2, the right quadrant
        if x<100 and y>=100: # if it's in the lower-left
            if x<200-y: # and above the line
                quadrant=1 # it's quadrant 1, the left quadrant
            else: # otherwise
                quadrant=3 # it's quadrant 3, the bottom quadrant
        if x>=100 and y>=100: # if it's in the bottom-right
            if x>y: # and above the line
                quadrant=2 # it's quadrant 2, the right quadrant
            else: # otherwise
                quadrant=3 # it's quadrant 3, the bottom quadrant

        # use this column, row, and quadrant to access the drawn triangle
        # and return that int
        return self.all_pieces.get((column,row,quadrant))

    def eyedropper(self, event):
        """
        Get the color from the clicked triangle.
        Parameter:
            event (sequence): data describing the input. In this case, it's
            just the mouse cursor coordinates when the mouse was left-clicked.
        """
        num = self.click_process(event) # get the triangle reference
        self.color_entry.delete(0, END) # wipe the entry field
        self.color_entry.insert(0, self.colorlist[num-1]) # set to chosen color

    def paint_bucket(self, event):
        """
        Process the user's clicks into which triangle to color.
        Parameter:
            event (sequence): data describing the input. In this case, it's
            just the mouse cursor coordinates when the mouse was left-clicked.
        """
        num = self.click_process(event) # get the triangle reference

        # save the string in the text box
        chosen_color = self.color_entry.get()
        try: # try to use that string as a color
            self.pattern.itemconfig(num, fill=chosen_color)
        except: # if it didn't work
            chosen_color = colorchooser.askcolor()[1] # pop a chooser!
            if chosen_color != None: # if the user chooses a color and hits OK
                # color the clicked triangle with the chosen color
                self.pattern.itemconfig(num, fill=chosen_color)
                self.color_entry.delete(0, END) # wipe the entry field
                self.color_entry.insert(0, chosen_color) # set to chosen color
            else: # if the user didn't write a good color and didn't pick one
                return # we're done here
        self.colorlist[num-1] = chosen_color # write chosen color to the list

def main():
    root = Tk() # Create a Tk object from tkinter.
    quilt_pattern = QuiltPattern(root) # Make my pattern inherit from that object.
    root.mainloop() # Run the main loop.

if __name__ == '__main__':
    main()
